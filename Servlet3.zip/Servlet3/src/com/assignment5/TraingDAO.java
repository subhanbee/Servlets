package com.assignment5;

import java.util.ArrayList;

public class TraingDAO {
	public static ArrayList<Training> all=new ArrayList<Training>();

public int saveTraining(Training t) {
	all.add(t);
	return 1 ;
	}
public int delete(int id) {
	int allId=0;
	for(int i=0;i<all.size();i++) {
		Training tr=all.get(i);
		if(id==tr.getTrainingID()) {
			allId=i;
		}
		
	}
	Training s=all.remove(allId);
	if(s!=null)
		return 1;
	else
		return 0;
}
public ArrayList<Training> getAll(){
	return all;
}

}
