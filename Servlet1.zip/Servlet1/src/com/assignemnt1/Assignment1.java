package com.assignemnt1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Assignment1
 */
@WebServlet("/Assignment1")
public class Assignment1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init() {
		System.out.println("Servlet init is method is called");
	}
    public Assignment1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//set content tye
		response.setContentType("text/html");
		//get the rinywriter
		PrintWriter out=response.getWriter();
		//add the sysouts
		out.print("<html><head>\r\n" + 
				"<style>\r\n" + 
				"table, th, td {\r\n" + 
				"  border: 1px solid black;\r\n" + 
				"  border-collapse: collapse;\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"</head><body>");
		out.print("<h1>Hello World!</h1>");
		out.print("<table border=solid>");
		for(int i=0;i<25;i++) {
			out.print("<tr>");
			for(int j=0;j<3;j++) {
		out.print("<td>");
		out.print("RowX"+i+",Col"+j);
		out.print("</td>");
			}
			out.print("</tr>");
		}
		out.print("</table>");
		
		out.print("</body></html>");
	}
	

}
