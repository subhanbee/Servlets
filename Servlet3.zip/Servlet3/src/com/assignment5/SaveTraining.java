package com.assignment5;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveTraining
 */
@WebServlet("/SaveServlet")
public class SaveTraining extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final DateTimeFormatter PARSE_FORMATTER
    = DateTimeFormatter.ofPattern("MM/dd/uuuu");

    
    public SaveTraining() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String trainingID=request.getParameter("TrainingID");
		String trainingName=request.getParameter("TrainingName");
		String startdate=request.getParameter("Startdate");
		String endDate=request.getParameter("EndDate");	
		String trainingMode=request.getParameter("TrainingMode");
		String businisessUnit=request.getParameter("BusinisessUnit");
		String contactpersonID=request.getParameter("ContactpersonID");
		Date start=null;
		Date end=null;
		try {
			 start=new SimpleDateFormat("dd/MM/yyyy").parse(startdate);
			 end=new SimpleDateFormat("dd/MM/yyyy").parse(endDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Training tr=new Training();
		tr.setTrainingID(Integer.parseInt(trainingID));
		tr.setTrainingName(trainingName);
		tr.setStartdate(start);
		tr.setEndDate(end);
		tr.setTrainingMode(trainingMode);
		tr.setBusinisessUnit(businisessUnit);
		tr.setContactpersonID(Long.parseLong(contactpersonID));
		
		TraingDAO dao=new TraingDAO();
		int status=dao.saveTraining(tr);
		if(status>0) {
			out.print("Trainging details added successfully");
		 request.getRequestDispatcher("AddTraining.html").include(request, response);  }
		else{  
    out.println("Sorry! unable to save record");  
		}  
  

}
}
