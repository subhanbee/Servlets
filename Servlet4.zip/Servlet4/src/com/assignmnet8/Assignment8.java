package com.assignmnet8;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Assignment8
 */
@WebServlet("/Assignment8")
public class Assignment8 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Assignment8() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");  
		    PrintWriter out = response.getWriter();  
		          
		    String n=request.getParameter("userName");  
		    String p=request.getParameter("password");
		    out.print("Welcome "+n);  
		  
		    Cookie ck=new Cookie("uname",n);//creating cookie object  ]
		  Cookie ck1=new Cookie("pass",p);
		    response.addCookie(ck);//adding cookie in the response
		    response.addCookie(ck1);
		    
		  
		    //creating submit button  
		    out.print("<form action='servlet2' method='post'>");  
		    out.print("<input type='submit' value='go'>");  
		    out.print("</form>");  
	}

}
