package com.assignment4;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Assignment4
 */
@WebServlet("/Assignment4")
public class Assignment4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Assignment4() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("UserName");
		
		String password=request.getParameter("Password");
		String user=request.getParameter("userType");
		if(user.equals("E")&&username.equals("user123")&&password.equals("user123")) {
			RequestDispatcher rd=request.getRequestDispatcher("EmployeeHomepage"); 
	        rd.forward(request, response); 
		}
		else if(user.equals("A")&&username.equals("admin123")&&password.equals("admin123")) {
			RequestDispatcher rd=request.getRequestDispatcher("AdminHomepage"); 
	        rd.forward(request, response); 
			
		}
		else {
			 out.print("Sorry UserName or Password Error!");  
        RequestDispatcher rd=request.getRequestDispatcher("/User.html");  
       rd.include(request, response);  
		}
	}

}
