package com.assignment2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Assignment2
 */
@WebServlet("/Assignment2")
public class Assignment2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Assignment2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		 GregorianCalendar time = new GregorianCalendar();
		  int hour = time.get(Calendar.HOUR_OF_DAY);
		  int min = time.get(Calendar.MINUTE);
		  int day = time.get(Calendar.DAY_OF_MONTH);
		  int month = time.get(Calendar.MONTH) + 1;
		  int year = time.get(Calendar.YEAR);

		  
		  out.print("<html><head>");
		  if (hour < 12)
		   out.println("Good Morning!  "+request.getParameter("Name"));
		  else if (hour < 17 && !(hour == 12))
		   out.println("Good Afternoon "+request.getParameter("Name"));
		  else if (hour == 12)
		  out.println("Good Noon "+request.getParameter("Name"));
		  else
		   out.println("Good Evening "+request.getParameter("Name"));
		 

	}

}
