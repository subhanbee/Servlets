package com.assignment5;

import java.util.Date;

public class Training {

	private int TrainingID;
	private String TrainingName;
	private Date Startdate;
	private Date EndDate;
	private String TrainingMode;
	private String BusinisessUnit;
	private long ContactpersonID;
	
	public Training() {
		super();
	}
	public Training(int trainingID, String trainingName, Date startdate, Date endDate, String trainingMode,
			String businisessUnit, long contactpersonID) {
		super();
		TrainingID = trainingID;
		TrainingName = trainingName;
		Startdate = startdate;
		EndDate = endDate;
		TrainingMode = trainingMode;
		BusinisessUnit = businisessUnit;
		ContactpersonID = contactpersonID;
	}
	public int getTrainingID() {
		return TrainingID;
	}
	public void setTrainingID(int trainingID) {
		TrainingID = trainingID;
	}
	public String getTrainingName() {
		return TrainingName;
	}
	public void setTrainingName(String trainingName) {
		TrainingName = trainingName;
	}
	public Date getStartdate() {
		return Startdate;
	}
	public void setStartdate(Date startdate) {
		Startdate = startdate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public String getTrainingMode() {
		return TrainingMode;
	}
	public void setTrainingMode(String trainingMode) {
		TrainingMode = trainingMode;
	}
	public String getBusinisessUnit() {
		return BusinisessUnit;
	}
	public void setBusinisessUnit(String businisessUnit) {
		BusinisessUnit = businisessUnit;
	}
	public long getContactpersonID() {
		return ContactpersonID;
	}
	public void setContactpersonID(long contactpersonID) {
		ContactpersonID = contactpersonID;
	}
	
}
